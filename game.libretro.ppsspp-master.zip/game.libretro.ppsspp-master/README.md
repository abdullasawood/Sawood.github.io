# Sony - PlayStation Portable (PPSSPP)

### Description

PPSSPP is a fast and portable PSP emulator written in C++.

### License

GPLv2

### Icon

![Sony - PlayStation Portable (PPSSPP) icon](game.libretro.ppsspp/resources/icon.png)

### Fanart

Help make me fanart!

### Screenshots

Help make me screenshots!

### Disclaimer

*Originally created by Henrik Rydgård*
